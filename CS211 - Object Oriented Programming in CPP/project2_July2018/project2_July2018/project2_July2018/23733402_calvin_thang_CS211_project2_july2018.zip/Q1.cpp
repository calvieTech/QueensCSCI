#include <iostream>
#include <cmath>
#include <string>
#include <sstream>
using namespace std;

class Message1{
public:
    Message1() {
        _date = 0;
        
    }
    
    Message1(string f) {
        _from = addDomain(f);
        _date = 0;
    }
    
    Message1(string f, string t) {
        _from = addDomain(f);
        _to = addDomain(t);
        _date = 0;
    }
    
    Message1(string f, string t, string s) {
        _subject = s;
        _from = addDomain(f);
        _to = addDomain(t);
    }
    
    Message1(string f, string t, string s, string txt) {
        _text = txt;
        _from = addDomain(f);
        _to = addDomain(t);
        _subject = s;
    }

    string from() const {
        return _from;
    }
    
    string to() const {
        return _to;
    }
    
    string subject() const {
        return _subject;
    }
    
    string text() const {
        return _text;
    }
    
    string date() const {
        return string("n/a");
    }
    
    
    void setSubject(string s) {
        _subject = s;
    }
    
    void setText(string txt) {
        _text = txt;
    }
    
    void prependText(string input) {
        string blank = " ";
        _text = input + blank + _text;
    }
    
    void appendText(string t) {
        string blank = " ";
        _text = _text + blank + t;
    }
    
    void setRecipient(string t) {
        _to = addDomain(t);
    }
    
    void print() const {
        cout << "From: " << _from << endl;
        cout << "To: " << _to << endl;
        cout << "Subject: " << _subject << endl;
        cout << "Date: " << date() << endl;
        cout << _text << endl;
        cout << endl;
    }
    
    
    
    
    
    
private:
    string _from;
    string _to;
    string _subject;
    string _text;
    int _date;
    
    string addDomain(string s) {
        const string _domain = "@qc.cuny.edu";
        istringstream iss(s); //istringstream removes leading and trailing blanks from s
        iss >> s;
        string email = s + _domain;
        return email;
    }
    
};


ostream& operator<< (ostream& os, const Message1 &m) {
    os << "From: " << m.from() << endl;
    os << "To: " << m.to() << endl;
    os << "Subject: " << m.subject() << endl;
    os << "Date: " << m.date() << endl;
    os << m.text() << endl;
    return os;
}



int main() {
    
    Message1 _email1;
    Message1 _email2("Calvin");
    Message1 _email3("Calvin", "Sateesh");
    Message1 _email4("Calvin", "Sateesh", "project2_2018");
    Message1 _email5("Calvin", "Sateesh", "project2_2018", "Am I doing this correctly?");
    
    cout << "_email1" << endl;
    cout << _email1 << endl;
    _email1.setSubject("Subject for _email1");
    cout << _email1 << endl;
    
    cout << "_email2" << endl;
    cout << _email2 << endl;
    _email2.setText("This is going to nobody");
    cout << "Text in _email2: " << _email2.text() << endl;
    _email2.prependText("Honestly...");
    cout << "Prepended text in _email2: " << _email2.text() << endl << endl;
    

    cout << "_email3" << endl;
    cout << _email3 << endl;
    _email3.setSubject("Question");
    _email3.setText("How much effort is necessary for an A/A+ in this class?");
    cout << "_email3 Subject: " << _email3.subject() << endl;
    cout << "_email3 Text: " << _email3.text() << endl;
    _email3.appendText("I am willing to work hard for an A/A+ in this class");
    cout << endl;
    _email3.print();
    
    cout << "_email4" << endl;
    cout << _email4 << endl;
    _email4.setText("I think Q1 is really neat");
    cout << _email4 << endl;
    
    cout << "_email5" << endl;
    cout << _email5 << endl;
    
    
    return 0;
    
    
    
    
}
