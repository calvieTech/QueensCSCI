#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>
using namespace std;

int bounding_rect(int n, int x[], int y[], int u[], int v[]);

int main() {
    return 0;
}


int bounding_rect(int n, int x[], int y[], int u[], int v[]) {
    
    n--;
    int A = n * n;
    return A;
    
}
